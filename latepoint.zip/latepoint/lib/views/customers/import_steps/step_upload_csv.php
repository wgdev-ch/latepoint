<div class="customer-csv-step" data-customer-csv-step="upload_csv" data-customer-csv-next-btn="Continue">
	<?php echo OsFormHelper::file_upload_field('latepoint_customers_csv', __('Select CSV file to upload', 'latepoint'), '', [], [], '.csv'); ?>
</div>