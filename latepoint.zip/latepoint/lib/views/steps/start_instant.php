<?php
/* @var $atts array */
?>
<?php echo OsShortcodesHelper::shortcode_latepoint_book_form($atts); ?>