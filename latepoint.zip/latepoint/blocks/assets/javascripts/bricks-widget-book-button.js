function init_booking_button(){
    window.latepoint_init_booking_form_by_trigger = function(e) {
        e.preventDefault();
    };
}